export class CustomPageObjects {
    public username = 'developer';
    public password = 'Z6mEwN1UFq0k#pQ0';

    public doNavigationSISPortal() {
        cy.visit('https://sisenterprisewebcypresstraining.azurewebsites.net/');
    }

    public doLogin(username: string, password: string) {
        cy.get('input[id="username"]').type(username);// username
        cy.get('input[id="password"]').type(password);// password
        cy.get('#LoginButton').click();
    }

    public doGetElement(elementid) {
        return cy.get(`[data-test-id="${elementid}"]`);
    }

    public doClickByText(element: Cypress.Chainable<JQuery<HTMLElement>>, textToBeClicked: string, index: number = 0) {
        element.then((elem) => {
            elem.toArray().forEach((x, n) => {
                index == 0 && (x.innerText == textToBeClicked) && x.click();
                index != 0 && index == n && (x.innerText == textToBeClicked) && x.click();
            })
        })
    }
};